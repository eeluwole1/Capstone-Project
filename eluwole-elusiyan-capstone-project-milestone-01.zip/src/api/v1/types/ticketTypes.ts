// types/ticketTypes.ts
export interface Ticket {
    id: string;
    event_id: number;
    user_id: number;
    status: string;
  }
  