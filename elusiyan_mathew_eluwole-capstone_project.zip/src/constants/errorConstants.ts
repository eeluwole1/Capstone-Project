/** Default error code used when no specific code can be determined */
export const UNKNOWN_ERROR_CODE = "UNKNOWN_ERROR";
